import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import './ThresholdMaterial.js' // registers <thresholdMaterial/>
import { view } from '../lib/store'

// The brand made geometry: a sphere of matter perturbed by noise, lit by an
// iridescent fresnel rim. It eases toward the pointer and tightens on scroll.
export default function Threshold({ detail = 48 }) {
  const mat = useRef()
  const group = useRef()
  const pointer = useRef(0)

  useFrame((state, delta) => {
    const d = Math.min(1, delta * 2.5)
    const t = state.clock.elapsedTime

    if (mat.current) {
      mat.current.uTime = t
      pointer.current += (view.pStr - pointer.current) * d
      mat.current.uPointer = pointer.current
      mat.current.uScroll = view.progress
    }

    if (group.current) {
      group.current.rotation.y += delta * 0.08
      const targetX = -view.py * 0.18
      const targetPosX = view.px * 0.22
      group.current.rotation.x += (targetX - group.current.rotation.x) * d
      group.current.position.x += (targetPosX - group.current.position.x) * d
      const s = 1 - view.progress * 0.22
      group.current.scale.setScalar(s)
    }
  })

  return (
    <group ref={group}>
      <mesh>
        <icosahedronGeometry args={[1.4, detail]} />
        <thresholdMaterial ref={mat} toneMapped={false} />
      </mesh>
    </group>
  )
}
