import { Suspense } from 'react'
import { Canvas } from '@react-three/fiber'
import { EffectComposer, Bloom, Vignette } from '@react-three/postprocessing'
import Threshold from './Threshold'
import Motes from './Motes'

// The fixed, full-viewport WebGL backdrop. DOM content scrolls above it.
export default function Scene({ quality }) {
  return (
    <Canvas
      dpr={quality.dpr}
      gl={{ antialias: true, alpha: false, powerPreference: 'high-performance' }}
      camera={{ position: [0, 0, 5], fov: 42 }}
    >
      <color attach="background" args={['#0b0b0f']} />
      <Suspense fallback={null}>
        <Threshold detail={quality.detail} />
        <Motes count={quality.motes} />
      </Suspense>
      <EffectComposer disableNormalPass>
        <Bloom mipmapBlur luminanceThreshold={0.5} intensity={0.85} radius={0.7} />
        <Vignette offset={0.25} darkness={0.82} />
      </EffectComposer>
    </Canvas>
  )
}
