// GLSL for "the Threshold" — a sphere of matter held mid-formation.
// Inlined as strings so the build needs no GLSL plugin or external assets.

// Classic textureless 3D simplex noise (Ashima Arts / Stefan Gustavson, MIT).
const snoise = /* glsl */ `
vec4 permute(vec4 x){ return mod(((x*34.0)+1.0)*x, 289.0); }
vec4 taylorInvSqrt(vec4 r){ return 1.79284291400159 - 0.85373472095314 * r; }

float snoise(vec3 v){
  const vec2 C = vec2(1.0/6.0, 1.0/3.0);
  const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);
  vec3 i  = floor(v + dot(v, C.yyy));
  vec3 x0 = v - i + dot(i, C.xxx);
  vec3 g = step(x0.yzx, x0.xyz);
  vec3 l = 1.0 - g;
  vec3 i1 = min(g.xyz, l.zxy);
  vec3 i2 = max(g.xyz, l.zxy);
  vec3 x1 = x0 - i1 + 1.0 * C.xxx;
  vec3 x2 = x0 - i2 + 2.0 * C.xxx;
  vec3 x3 = x0 - 1.0 + 3.0 * C.xxx;
  i = mod(i, 289.0);
  vec4 p = permute( permute( permute(
            i.z + vec4(0.0, i1.z, i2.z, 1.0))
          + i.y + vec4(0.0, i1.y, i2.y, 1.0))
          + i.x + vec4(0.0, i1.x, i2.x, 1.0));
  float n_ = 1.0/7.0;
  vec3 ns = n_ * D.wyz - D.xzx;
  vec4 j = p - 49.0 * floor(p * ns.z * ns.z);
  vec4 x_ = floor(j * ns.z);
  vec4 y_ = floor(j - 7.0 * x_);
  vec4 x = x_ * ns.x + ns.yyyy;
  vec4 y = y_ * ns.x + ns.yyyy;
  vec4 h = 1.0 - abs(x) - abs(y);
  vec4 b0 = vec4( x.xy, y.xy );
  vec4 b1 = vec4( x.zw, y.zw );
  vec4 s0 = floor(b0)*2.0 + 1.0;
  vec4 s1 = floor(b1)*2.0 + 1.0;
  vec4 sh = -step(h, vec4(0.0));
  vec4 a0 = b0.xzyw + s0.xzyw*sh.xxyy;
  vec4 a1 = b1.xzyw + s1.xzyw*sh.zzww;
  vec3 p0 = vec3(a0.xy, h.x);
  vec3 p1 = vec3(a0.zw, h.y);
  vec3 p2 = vec3(a1.xy, h.z);
  vec3 p3 = vec3(a1.zw, h.w);
  vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2,p2), dot(p3,p3)));
  p0 *= norm.x; p1 *= norm.y; p2 *= norm.z; p3 *= norm.w;
  vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
  m = m * m;
  return 42.0 * dot( m*m, vec4(dot(p0,x0), dot(p1,x1), dot(p2,x2), dot(p3,x3)) );
}
`

export const vertexShader = /* glsl */ `
uniform float uTime;
uniform float uAmp;
uniform float uFreq;
uniform float uSpeed;
uniform float uPointer;
uniform float uScroll;

varying vec3 vNormal;
varying vec3 vView;
varying float vDisp;

${snoise}

vec3 orthogonal(vec3 v){
  return normalize(abs(v.x) > abs(v.z)
    ? vec3(-v.y, v.x, 0.0)
    : vec3(0.0, -v.z, v.y));
}

// Two octaves of noise, modulated by pointer (amplitude) and scroll (frequency).
float pattern(vec3 p){
  float t = uTime * uSpeed;
  float amp = uAmp * (1.0 + uPointer * 0.85);
  float freq = uFreq * (1.0 + uScroll * 0.5);
  float n = snoise(p * freq + vec3(0.0, t * 0.2, 0.0));
  n += 0.5 * snoise(p * freq * 2.0 - vec3(t * 0.15));
  return n * amp;
}

vec3 distortPoint(vec3 p){
  vec3 n = normalize(p);
  return p + n * pattern(p);
}

void main(){
  float offset = 0.2;
  vec3 t1 = orthogonal(normal);
  vec3 t2 = normalize(cross(normal, t1));

  vec3 v0 = distortPoint(position);
  vec3 v1 = distortPoint(position + t1 * offset);
  vec3 v2 = distortPoint(position + t2 * offset);
  vec3 newNormal = normalize(cross(v1 - v0, v2 - v0));

  vDisp = pattern(position);

  vec4 mvPosition = modelViewMatrix * vec4(v0, 1.0);
  vNormal = normalize(normalMatrix * newNormal);
  vView = normalize(-mvPosition.xyz);
  gl_Position = projectionMatrix * mvPosition;
}
`

export const fragmentShader = /* glsl */ `
uniform float uTime;
uniform float uFresnel;
uniform vec3 uColorA;
uniform vec3 uEmber;

varying vec3 vNormal;
varying vec3 vView;
varying float vDisp;

// Inigo Quilez cosine palette — the spectral "threshold" iridescence.
vec3 palette(float t){
  vec3 a = vec3(0.5);
  vec3 b = vec3(0.5);
  vec3 c = vec3(1.0);
  vec3 d = vec3(0.0, 0.33, 0.67);
  return a + b * cos(6.28318 * (c * t + d));
}

void main(){
  vec3 N = normalize(vNormal);
  vec3 V = normalize(vView);
  float fres = pow(1.0 - clamp(dot(N, V), 0.0, 1.0), uFresnel);

  vec3 spectral = palette(fres * 0.7 + vDisp * 0.6 + uTime * 0.03);
  vec3 col = mix(uColorA, spectral, smoothstep(0.05, 0.9, fres));
  col += spectral * max(vDisp, 0.0) * 0.25;   // glow on crests
  col += uEmber * pow(fres, 5.0) * 0.6;        // ember at the grazing rim

  gl_FragColor = vec4(col, 1.0);
}
`
