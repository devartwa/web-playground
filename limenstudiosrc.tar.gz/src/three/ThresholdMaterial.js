import * as THREE from 'three'
import { shaderMaterial } from '@react-three/drei'
import { extend } from '@react-three/fiber'
import { vertexShader, fragmentShader } from './shaders'

// Drei's shaderMaterial wires the uniforms and gives us a JSX element
// (<thresholdMaterial/>) once registered with extend().
export const ThresholdMaterial = shaderMaterial(
  {
    uTime: 0,
    uAmp: 0.42,
    uFreq: 0.85,
    uSpeed: 0.55,
    uPointer: 0,
    uScroll: 0,
    uFresnel: 3.0,
    uColorA: new THREE.Color('#0a0712'),
    uEmber: new THREE.Color('#ff4d2e'),
  },
  vertexShader,
  fragmentShader
)

extend({ ThresholdMaterial })
