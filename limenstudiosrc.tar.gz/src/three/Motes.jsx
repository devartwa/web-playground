import { useMemo, useRef, useEffect } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { view } from '../lib/store'

// A soft radial sprite, generated at runtime so we ship no image assets.
function makeSprite() {
  const size = 64
  const c = document.createElement('canvas')
  c.width = c.height = size
  const ctx = c.getContext('2d')
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2)
  g.addColorStop(0, 'rgba(255,255,255,1)')
  g.addColorStop(0.25, 'rgba(255,255,255,0.6)')
  g.addColorStop(1, 'rgba(255,255,255,0)')
  ctx.fillStyle = g
  ctx.fillRect(0, 0, size, size)
  return new THREE.CanvasTexture(c)
}

// A slow field of motes around the Threshold — atmosphere, not detail.
export default function Motes({ count = 700 }) {
  const points = useRef()
  const sprite = useMemo(() => makeSprite(), [])

  const positions = useMemo(() => {
    const arr = new Float32Array(count * 3)
    for (let i = 0; i < count; i++) {
      const r = 2.3 + Math.random() * 3.6
      const theta = Math.random() * Math.PI * 2
      const phi = Math.acos(2 * Math.random() - 1)
      arr[i * 3] = r * Math.sin(phi) * Math.cos(theta)
      arr[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta)
      arr[i * 3 + 2] = r * Math.cos(phi)
    }
    return arr
  }, [count])

  useEffect(() => () => sprite.dispose(), [sprite])

  useFrame((state, delta) => {
    if (!points.current) return
    points.current.rotation.y += delta * 0.02
    points.current.rotation.x += (view.py * 0.12 - points.current.rotation.x) * Math.min(1, delta * 1.5)
    const breathe = 1 + Math.sin(state.clock.elapsedTime * 0.4) * 0.04
    points.current.scale.setScalar(breathe)
  })

  return (
    <points ref={points}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial
        map={sprite}
        size={0.07}
        sizeAttenuation
        transparent
        depthWrite={false}
        blending={THREE.AdditiveBlending}
        color="#9b93ff"
        opacity={0.7}
      />
    </points>
  )
}
