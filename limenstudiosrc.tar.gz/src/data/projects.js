// Fictional case studies — see BRAND.md for the full studio story.
export const projects = [
  {
    id: 'aura',
    index: '01',
    title: 'AURA',
    client: 'Maison Vésper',
    year: '2024',
    disciplines: ['WebGL', 'Art Direction'],
    blurb: 'A scent translated into light — a fragrance launch where the notes become a living field of particles.',
    accent: '#FF4D2E',
  },
  {
    id: 'terra',
    index: '02',
    title: 'TERRA 2049',
    client: 'Instituto Horizonte',
    year: '2023',
    disciplines: ['Data', 'Interactive'],
    blurb: 'A climate installation you can scrub through — 25 years of a possible future, rendered as terrain.',
    accent: '#3DDC97',
  },
  {
    id: 'pulse',
    index: '03',
    title: 'PULSE',
    client: 'KÁOS',
    year: '2024',
    disciplines: ['Real-time', 'Audio-reactive'],
    blurb: 'An album that listens back. A site that re-renders itself to whatever is playing, in real time.',
    accent: '#6E5BFF',
  },
  {
    id: 'movel',
    index: '04',
    title: 'MÓVEL',
    client: 'Lina',
    year: '2022',
    disciplines: ['3D', 'Product'],
    blurb: 'A configurator that feels like a showroom — real-time materials, light and shadow you can walk a chair through.',
    accent: '#E8B84B',
  },
  {
    id: 'noir',
    index: '05',
    title: 'NOIR',
    client: 'Verõ',
    year: '2023',
    disciplines: ['Film', 'Identity'],
    blurb: 'A brand film and immersive lookbook for a fashion label that only ever works in black.',
    accent: '#EDEAE3',
  },
  {
    id: 'orbita',
    index: '06',
    title: 'ÓRBITA',
    client: 'Stela Aerospace',
    year: '2025',
    disciplines: ['Platform', 'Visualization'],
    blurb: 'Orbital mechanics made legible — and beautiful — for the people who fund space, not fly it.',
    accent: '#4CC9F0',
  },
]

export const services = [
  {
    n: '01',
    title: 'Creative Direction',
    body: 'The idea before the interface. We set the concept, the art direction and the rules everything else obeys.',
  },
  {
    n: '02',
    title: 'Interactive & WebGL',
    body: 'Real-time graphics, shaders and physics. The part most studios outsource is the part we live in.',
  },
  {
    n: '03',
    title: 'Brand & Identity',
    body: 'Marks, type systems and motion languages built to move — designed for the screen they will live on.',
  },
  {
    n: '04',
    title: 'Motion & Film',
    body: 'Title sequences, brand films and the connective tissue between a campaign and an experience.',
  },
  {
    n: '05',
    title: 'Design Systems & Product',
    body: 'When the experience has to scale, we build the components, tokens and front-end to keep it alive.',
  },
]

export const studio = {
  founded: '2019',
  cities: ['São Paulo', 'Lisboa'],
  size: '9 people, on purpose',
  awards: ['Awwwards · Site of the Day ×4', 'FWA of the Day ×3', 'Webby · Nominee'],
  people: [
    { name: 'Ivo Mendara', role: 'Founder & Creative Director' },
    { name: 'Rafa Queiroz', role: 'Technical Director' },
    { name: 'Nina Okabe', role: 'Design Director' },
  ],
}

export const nav = [
  { label: 'Work', href: '#work' },
  { label: 'Studio', href: '#studio' },
  { label: 'Services', href: '#services' },
  { label: 'Contact', href: '#contact' },
]
