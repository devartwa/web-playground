import { Fragment, useRef } from 'react'
import { useReveal } from '../lib/useReveal'

// Each token becomes a masked word so the statement assembles itself on scroll.
const TOKENS = [
  'We', "don't", 'make', 'websites.', 'We', 'make',
  { t: 'thresholds', c: 'accent' }, '—', 'places', 'you', 'cross', 'into',
  'and', 'leave', { t: 'changed.', c: 'em' },
]

export default function Manifesto() {
  const root = useRef()
  useReveal(root)

  return (
    <section className="section container" ref={root}>
      <p className="eyebrow" data-reveal="fade">
        Manifesto
      </p>
      <h2 className="manifesto__text" data-reveal="words" style={{ marginTop: '2.5rem' }}>
        {TOKENS.map((tok, i) => {
          const text = typeof tok === 'string' ? tok : tok.t
          const cls = typeof tok === 'string' ? '' : tok.c
          return (
            <Fragment key={i}>
              <span className="word">
                <span className={cls}>{text}</span>
              </span>{' '}
            </Fragment>
          )
        })}
      </h2>
    </section>
  )
}
