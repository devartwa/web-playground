import { nav } from '../data/projects'

export default function Nav() {
  const go = (e, href) => {
    e.preventDefault()
    const el = document.querySelector(href)
    if (window.__lenis && el) window.__lenis.scrollTo(el)
    else if (el) el.scrollIntoView({ behavior: 'smooth' })
  }

  const toTop = (e) => {
    e.preventDefault()
    if (window.__lenis) window.__lenis.scrollTo(0)
    else window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <header className="nav">
      <a href="#top" className="nav__brand" data-cursor onClick={toTop}>
        LÍMEN
      </a>
      <nav className="nav__links">
        {nav.map((n) => (
          <a key={n.href} href={n.href} data-cursor onClick={(e) => go(e, n.href)}>
            {n.label}
          </a>
        ))}
      </nav>
    </header>
  )
}
