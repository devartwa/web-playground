import { Component } from 'react'

// Keeps a WebGL/shader failure from taking the whole site down: if the 3D
// throws, we fall back to a static gradient and the content still reads.
export default class ErrorBoundary extends Component {
  constructor(props) {
    super(props)
    this.state = { failed: false }
  }

  static getDerivedStateFromError() {
    return { failed: true }
  }

  componentDidCatch(error) {
    // eslint-disable-next-line no-console
    console.warn('[LÍMEN] WebGL layer failed, falling back.', error)
  }

  render() {
    if (this.state.failed) {
      return this.props.fallback ?? <div className="canvas-fallback" />
    }
    return this.props.children
  }
}
