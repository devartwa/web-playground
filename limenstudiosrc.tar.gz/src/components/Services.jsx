import { useRef } from 'react'
import { services } from '../data/projects'
import { useReveal } from '../lib/useReveal'

export default function Services() {
  const root = useRef()
  useReveal(root)

  return (
    <section className="section container" id="services" ref={root}>
      <p className="eyebrow" data-reveal="fade">
        Capabilities
      </p>
      <div className="services__grid" style={{ marginTop: '3rem' }}>
        {services.map((s) => (
          <div className="service" key={s.n} data-reveal="fade">
            <span className="service__n">{s.n}</span>
            <div>
              <h3 className="service__title">{s.title}</h3>
              <p className="service__body">{s.body}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
