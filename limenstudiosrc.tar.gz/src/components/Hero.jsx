const LETTERS = ['L', 'Í', 'M', 'E', 'N']

// Markup only — the intro timeline lives in App and fires once the preloader
// uncovers, so the hand-off from loader to hero is choreographed in one place.
export default function Hero() {
  return (
    <section className="hero container" id="top">
      <h1 className="hero__title">
        <span className="line">
          {LETTERS.map((c, i) => (
            <span className="char" key={i}>
              {c}
            </span>
          ))}
        </span>
      </h1>

      <div className="hero__meta">
        <p className="hero__tagline">
          <span className="line">
            <span>Designing the threshold between</span>
          </span>
          <span className="line">
            <span>art and technology.</span>
          </span>
          <span className="pt">Um estúdio de creative technology. São Paulo / Lisboa.</span>
        </p>
        <div className="hero__scroll">Scroll</div>
      </div>
    </section>
  )
}
