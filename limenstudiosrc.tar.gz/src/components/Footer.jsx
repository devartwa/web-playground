export default function Footer() {
  const year = new Date().getFullYear()
  return (
    <footer className="footer">
      <div className="container footer__row">
        <span className="nav__brand">LÍMEN</span>
        <div className="footer__socials">
          <a href="#" data-cursor>
            Instagram
          </a>
          <a href="#" data-cursor>
            Are.na
          </a>
          <a href="#" data-cursor>
            LinkedIn
          </a>
        </div>
        <span className="footer__fine">© {year} LÍMEN — São Paulo / Lisboa · a fictional brand</span>
      </div>
    </footer>
  )
}
