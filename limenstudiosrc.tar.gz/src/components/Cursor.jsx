import { useEffect, useRef } from 'react'
import { gsap } from '../lib/gsap'

// A two-part custom cursor (dot + trailing ring) that grows over interactive
// elements. Uses mix-blend-mode in CSS so it inverts against whatever it covers.
export default function Cursor() {
  const dot = useRef()
  const ring = useRef()

  useEffect(() => {
    if (window.matchMedia('(hover: none), (pointer: coarse)').matches) return

    gsap.set([dot.current, ring.current], { xPercent: -50, yPercent: -50, x: -100, y: -100 })

    const xDot = gsap.quickTo(dot.current, 'x', { duration: 0.12, ease: 'power3' })
    const yDot = gsap.quickTo(dot.current, 'y', { duration: 0.12, ease: 'power3' })
    const xRing = gsap.quickTo(ring.current, 'x', { duration: 0.45, ease: 'power3' })
    const yRing = gsap.quickTo(ring.current, 'y', { duration: 0.45, ease: 'power3' })

    const move = (e) => {
      xDot(e.clientX)
      yDot(e.clientY)
      xRing(e.clientX)
      yRing(e.clientY)
    }
    window.addEventListener('pointermove', move, { passive: true })

    const enter = () => gsap.to(ring.current, { scale: 1.8, duration: 0.4, ease: 'power3' })
    const leave = () => gsap.to(ring.current, { scale: 1, duration: 0.4, ease: 'power3' })
    const els = Array.from(document.querySelectorAll('a, button, [data-cursor]'))
    els.forEach((el) => {
      el.addEventListener('pointerenter', enter)
      el.addEventListener('pointerleave', leave)
    })

    return () => {
      window.removeEventListener('pointermove', move)
      els.forEach((el) => {
        el.removeEventListener('pointerenter', enter)
        el.removeEventListener('pointerleave', leave)
      })
    }
  }, [])

  return (
    <>
      <div ref={ring} className="cursor-ring" />
      <div ref={dot} className="cursor" />
    </>
  )
}
