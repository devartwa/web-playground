import { useRef } from 'react'
import { useReveal } from '../lib/useReveal'
import MagneticButton from './MagneticButton'

export default function Contact() {
  const root = useRef()
  useReveal(root)

  return (
    <section className="section container contact" id="contact" ref={root}>
      <p className="eyebrow" data-reveal="fade">
        Start something
      </p>
      <h2 className="contact__big" data-reveal="fade" style={{ marginTop: '1.5rem' }}>
        Let&rsquo;s cross over.
      </h2>
      <MagneticButton as="a" href="mailto:studio@limen.studio" className="contact__email">
        studio@limen.studio
      </MagneticButton>
    </section>
  )
}
