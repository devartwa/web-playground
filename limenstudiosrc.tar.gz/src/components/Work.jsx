import { useRef } from 'react'
import { projects } from '../data/projects'
import { useReveal } from '../lib/useReveal'

export default function Work() {
  const root = useRef()
  useReveal(root)

  const openContact = (e) => {
    e.preventDefault()
    if (window.__lenis) window.__lenis.scrollTo('#contact')
  }

  return (
    <section className="section container" id="work" ref={root}>
      <div className="work__head">
        <p className="eyebrow" data-reveal="fade">
          Selected Work
        </p>
        <span className="work__count" data-reveal="fade">
          {projects.length} projects · 2022—2025
        </span>
      </div>

      <div className="work__list">
        {projects.map((p) => (
          <a
            className="project"
            key={p.id}
            href="#contact"
            onClick={openContact}
            style={{ '--accent': p.accent }}
            data-reveal="fade"
          >
            <span className="project__index">{p.index}</span>
            <span className="project__title">
              {p.title}
              <small>{p.blurb}</small>
            </span>
            <span className="project__meta">
              <span className="year">{p.year}</span>
              {p.disciplines.join(' · ')}
              <br />
              {p.client}
            </span>
            <span className="project__bar" />
          </a>
        ))}
      </div>
    </section>
  )
}
