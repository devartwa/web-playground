import { useRef } from 'react'
import { studio } from '../data/projects'
import { useReveal } from '../lib/useReveal'

export default function Studio() {
  const root = useRef()
  useReveal(root)

  return (
    <section className="section container" id="studio" ref={root}>
      <p className="eyebrow" data-reveal="fade">
        The Studio
      </p>
      <div className="studio__grid" style={{ marginTop: '3rem' }}>
        <p className="studio__lead" data-reveal="fade">
          LÍMEN is an independent creative-technology studio. We treat the digital as a material —
          with weight, light and behavior — and design the seam between worlds instead of hiding it.
        </p>

        <div className="studio__facts">
          <div className="fact" data-reveal="fade">
            <div className="fact__label">Founded</div>
            <div className="fact__value">
              {studio.founded} · {studio.cities.join(' / ')}
            </div>
          </div>
          <div className="fact" data-reveal="fade">
            <div className="fact__label">Team</div>
            <div className="fact__value">
              {studio.people.map((p) => (
                <span key={p.name}>
                  {p.name} — {p.role}
                </span>
              ))}
            </div>
          </div>
          <div className="fact" data-reveal="fade">
            <div className="fact__label">Recognition</div>
            <div className="fact__value">
              {studio.awards.map((a) => (
                <span key={a}>{a}</span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
