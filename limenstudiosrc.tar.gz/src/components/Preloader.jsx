import { useEffect, useRef, useState } from 'react'
import { gsap } from '../lib/gsap'
import { view } from '../lib/store'

// Full-screen overlay that counts "matter into being", then slides away to
// hand off to the hero. Calls onReveal as it starts sliding, onDone when gone.
export default function Preloader({ onReveal, onDone }) {
  const root = useRef()
  const bar = useRef()
  const [count, setCount] = useState(0)

  useEffect(() => {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const dur = reduced ? 0.4 : 2.0
    const obj = { v: 0 }

    const tl = gsap.timeline()
    tl.to(obj, {
      v: 100,
      duration: dur,
      ease: 'power2.inOut',
      onUpdate: () => setCount(Math.round(obj.v)),
    })
    tl.to(bar.current, { width: '100%', duration: dur, ease: 'power2.inOut' }, 0)
    tl.to('.preloader__inner', { y: -24, autoAlpha: 0, duration: 0.6, ease: 'power2.in' }, '>-0.1')
    tl.to(
      root.current,
      {
        yPercent: -100,
        duration: 1.0,
        ease: 'limen',
        onStart: () => {
          view.loaded = true
          onReveal?.()
        },
        onComplete: () => onDone?.(),
      },
      '>-0.2'
    )

    return () => tl.kill()
  }, [onReveal, onDone])

  return (
    <div className="preloader" ref={root}>
      <div className="preloader__inner">
        <div className="preloader__mark">LÍMEN</div>
        <div className="preloader__count">{String(count).padStart(3, '0')} — entering</div>
        <div className="preloader__bar">
          <span ref={bar} />
        </div>
      </div>
    </div>
  )
}
