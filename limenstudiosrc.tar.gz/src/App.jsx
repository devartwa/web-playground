import { useEffect, useRef, useState } from 'react'
import { initSmoothScroll } from './lib/lenis'
import { gsap, ScrollTrigger } from './lib/gsap'
import ErrorBoundary from './components/ErrorBoundary'
import Scene from './three/Scene'
import Cursor from './components/Cursor'
import Preloader from './components/Preloader'
import Nav from './components/Nav'
import Hero from './components/Hero'
import Manifesto from './components/Manifesto'
import Work from './components/Work'
import Services from './components/Services'
import Studio from './components/Studio'
import Contact from './components/Contact'
import Footer from './components/Footer'

// Tune the WebGL load to the device once, on first render.
function getQuality() {
  const w = window.innerWidth
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
  const mobile = w < 768
  return {
    dpr: mobile ? [1, 1.5] : [1, 2],
    detail: reduced ? 16 : mobile ? 24 : 48,
    motes: reduced ? 150 : mobile ? 300 : 700,
  }
}

export default function App() {
  const [showPreloader, setShowPreloader] = useState(true)
  const [revealed, setRevealed] = useState(false)
  const quality = useRef(getQuality())

  // Smooth scroll for the lifetime of the app.
  useEffect(() => initSmoothScroll(), [])

  // Let fonts/layout settle, then recalc ScrollTrigger positions.
  useEffect(() => {
    const id = setTimeout(() => ScrollTrigger.refresh(), 400)
    return () => clearTimeout(id)
  }, [])

  // Hero + nav intro, fired as the preloader uncovers.
  useEffect(() => {
    if (!revealed) return
    const ctx = gsap.context(() => {
      gsap
        .timeline({ defaults: { ease: 'limen' } })
        .from('.hero__title .char', { yPercent: 120, duration: 1.2, stagger: 0.07 })
        .from('.hero__tagline .line > span', { yPercent: 110, duration: 1, stagger: 0.12 }, '-=0.8')
        .from('.hero__scroll', { autoAlpha: 0, y: 12, duration: 0.8 }, '-=0.6')
        .from('.nav', { autoAlpha: 0, duration: 1 }, '-=0.9')
    })
    return () => ctx.revert()
  }, [revealed])

  return (
    <>
      <Cursor />

      {showPreloader && (
        <Preloader onReveal={() => setRevealed(true)} onDone={() => setShowPreloader(false)} />
      )}

      <div className="canvas-wrap">
        <ErrorBoundary>
          <Scene quality={quality.current} />
        </ErrorBoundary>
      </div>

      <div className="content">
        <Nav />
        <main>
          <Hero />
          <Manifesto />
          <Work />
          <Services />
          <Studio />
          <Contact />
        </main>
        <Footer />
      </div>
    </>
  )
}
