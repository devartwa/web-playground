import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Shaders are inlined as JS template strings (see src/three/*), so no GLSL
// plugin is required. Keeping the config lean keeps the build reproducible.
export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    port: 5173,
  },
  build: {
    target: 'es2020',
    chunkSizeWarningLimit: 1200,
  },
})
