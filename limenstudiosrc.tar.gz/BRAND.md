# LÍMEN — Brand Book

> _līmen_ (Latin) — **threshold**. The line you cross from one state into another.

LÍMEN is a fictional brand created as a from-scratch web project. This document
is the single source of truth for the studio's identity: who it is, who it
serves, how it sounds, and how it looks. The website in this repository is the
brand made real.

---

## 1. The Idea

**LÍMEN is an independent creative-technology studio that designs the threshold
between art and technology.**

We work in the liminal space — the in-between. Not quite physical, not quite
digital. The moment matter takes form. Our craft lives where art direction meets
real-time graphics, where a brand stops being a logo and becomes an experience
you move through.

- **Pronunciation:** /ˈli.men/ — "LEE-men"
- **Wordmark:** `LÍMEN` (all caps, acute accent retained)
- **Founded:** 2019 — São Paulo, Brazil · satellite studio in Lisbon, Portugal
- **Size:** independent, 9 people, deliberately small

### Tagline
> **Designing the threshold between art and technology.**
> _PT:_ O limiar entre arte e tecnologia.

### One-liner
LÍMEN crafts immersive digital experiences for brands that live on the edge of
culture — fashion, music, deep-tech and the institutions shaping what comes next.

### Manifesto (the long-form voice)
> We don't make websites. We make thresholds.
> Places you cross into and leave changed.
>
> Everything starts as raw material — light, type, motion, code — and we hold it
> at the edge of becoming. Not finished. Not still. Alive.
>
> Between the physical and the digital there is a seam. Most people hide it.
> We design it.

---

## 2. Personas

### 2.1 The Studio (internal personas)

These are the fictional people behind LÍMEN — useful for tone, bios and the
"Studio" section of the site.

- **Ivo Mendara — Founder & Creative Director.** Former architect turned motion
  designer. Believes "the interface is a material, not a surface." Obsessed with
  weight, timing and restraint.
- **Rafa Queiroz — Technical Director.** Graphics and real-time. Writes shaders
  the way other people sketch. Came from the demoscene and games.
- **Nina Okabe — Design Director.** Type, grids and identity systems. Keeps the
  studio honest about legibility when everyone else wants more chaos.

### 2.2 The Clients (audience personas)

Who hires LÍMEN, and why.

| Persona | Who they are | What they need | What they fear |
| --- | --- | --- | --- |
| **The Cultural Brand** | Fashion house, gallery, music label, festival | A statement digital piece that earns press and awards | Looking like everyone else; being "just a website" |
| **The Future-Tech Company** | AI / space / climate / hardware startup | To make something intangible feel real and human | Coming across as cold, technical or vaporware |
| **The Heritage Maison** | Luxury brand with decades of legacy | To feel current without betraying its soul | Trend-chasing; cheapening the brand |

---

## 3. Market & Positioning

- **Category:** boutique creative-technology / experiential web studio.
- **Reference peers (real, for calibration only):** Active Theory, Resn, Obys,
  Locomotive, Unseen Studio, Aristide Benoist, Bruno Simon.
- **Sweet spot:** the overlap between strong art direction and serious WebGL /
  real-time engineering. Many studios do one well. LÍMEN insists on both.
- **Differentiator — "matter-first":** we treat the digital as a material with
  weight and behavior, not a flat page to decorate. The medium is part of the
  message.
- **Engagement model:**
  - Project-based experiences (signature work) — the majority of revenue.
  - Retainers for brands with ongoing digital flagships.
  - Self-initiated R&D releases (open experiments) that feed the pipeline and
    the studio's reputation.
- **Proof (fictional):** Awwwards Sites of the Day, FWA of the Day, a Webby
  nomination, talks at conferences on real-time web.

---

## 4. Selected Work (fictional case studies)

These power the **Work** section of the site (`src/data/projects.js`).

1. **AURA** — _Maison Vésper_ (fragrance) · 2024 · WebGL / Art Direction
   A scent translated into light. An immersive launch experience for a perfume,
   where the fragrance's notes become a living field of particles.
2. **TERRA 2049** — _Instituto Horizonte_ (museum) · 2023 · Data / Interactive
   A climate installation and companion site that lets you scrub through 25
   years of a possible future, rendered as terrain.
3. **PULSE** — _KÁOS_ (electronic artist) · 2024 · Real-time / Audio-reactive
   An album that listens back. A real-time audio-reactive site that re-renders
   itself to whatever is playing.
4. **MÓVEL** — _Lina_ (design furniture) · 2022 · 3D / Product
   A configurator that feels like a showroom: real-time materials, light and
   shadow you can walk a chair through.
5. **NOIR** — _Verõ_ (fashion label) · 2023 · Film / Identity
   A brand film and immersive lookbook for a label that only works in black.
6. **ÓRBITA** — _Stela Aerospace_ · 2025 · Platform / Visualization
   A satellite-data platform that makes orbital mechanics legible — and
   beautiful — for non-engineers.

---

## 5. Verbal Identity

- **Voice:** confident, spare, a little poetic — but always precise.
- **Tone rules:**
  - Say less. A short true sentence beats a paragraph of adjectives.
  - Lowercase for body and labels; UPPERCASE for the wordmark and big statements.
  - Concrete over abstract: "matter", "threshold", "weight", "light" — not
    "synergy", "solutions", "innovative".
  - Bilingual by nature (EN primary, PT signature). Never translate literally.
- **Do say:** "We design the in-between." · "Matter, not surface." · "Cross over."
- **Don't say:** "cutting-edge solutions", "we leverage", "digital agency".

---

## 6. Visual Identity

### Palette
| Token | Hex | Use |
| --- | --- | --- |
| **Ink** | `#0B0B0F` | Primary background — near-black with a cool cast |
| **Ink-2** | `#111118` | Raised surfaces, section shifts |
| **Bone** | `#EDEAE3` | Primary text — warm off-white |
| **Mist** | `#8A8A93` | Secondary text, labels |
| **Ember** | `#FF4D2E` | The one accent — links, focus, key moments. Used sparingly |
| **Spectral** | iridescent cyan→magenta | Lives only in the 3D / glow. Never flat UI |

The discipline: a near-monochrome world (ink + bone) interrupted by **one**
warm accent (ember) and a luminous spectral glow that exists only in the WebGL.

### Typography
- **Display:** _Syne_ (variable) — characterful, architectural, set tight and big.
- **Text:** _Inter_ (variable) — neutral, legible, gets out of the way.
- Fonts are bundled via `@fontsource-variable/*` so the build is self-contained
  (no runtime CDN dependency).

### Motion
- Heavy, slow, deliberate. Nothing snaps. Everything has mass.
- Smooth scroll (Lenis) is the spine; GSAP ScrollTrigger choreographs reveals.
- Custom cursor; magnetic interactive elements; full-screen preloader counting
  matter into being.

### The 3D centerpiece — "the Threshold"
A single luminous form held mid-formation: a sphere of matter perturbed by
noise, lit by an iridescent fresnel rim, surrounded by a slow field of motes.
It reacts to the pointer and tightens as you scroll — matter responding to
attention. It _is_ the brand: form, caught at the threshold of becoming.

---

## 7. Tech (how the brand is built)

- **React + Vite** — app shell and tooling.
- **React Three Fiber + drei + postprocessing** — the WebGL layer.
- **Custom GLSL** — the Threshold's displacement + fresnel material.
- **GSAP + ScrollTrigger + Lenis** — motion and smooth scroll.

See `README.md` for how to run it.
