# LÍMEN — Creative Technology Studio

An immersive, from-scratch website for a **fictional** creative-technology
studio. Built as a web playground inspired by award-winning, WebGL-heavy
experiences (Bruno Simon, vectrfl, Active Theory, Obys…).

> **LÍMEN** — _līmen_ (Latin) = **threshold**. The studio designs the threshold
> between art and technology. The brand, personas, market and case studies are
> all invented — see **[BRAND.md](./BRAND.md)** for the full story.

![tech](https://img.shields.io/badge/React-18-1f1f28) ![tech](https://img.shields.io/badge/Three.js-r169-1f1f28) ![tech](https://img.shields.io/badge/R3F-8-1f1f28) ![tech](https://img.shields.io/badge/GSAP-3-1f1f28)

## The experience

- **A custom GLSL centerpiece** — "the Threshold": a sphere of matter perturbed
  by simplex noise with recomputed normals, lit by an iridescent fresnel rim and
  an ember accent. It eases toward the pointer and tightens as you scroll.
- **A field of motes** + **bloom / vignette** post-processing for atmosphere.
- **Smooth scroll** (Lenis) married to **GSAP ScrollTrigger** for choreographed
  reveals — masked word/line animations, fades on enter.
- **A full-screen preloader**, a **custom blend-mode cursor**, and **magnetic**
  interactive elements.
- **Graceful degradation**: if WebGL fails, an error boundary falls back to a
  static gradient and all content still reads. Reduced-motion and mobile get a
  lighter load.

## Run it

```bash
npm install
npm run dev        # http://localhost:5173 — this is where you SEE the 3D
npm run build      # production build into /dist
npm run preview    # serve the build locally
```

> The WebGL centerpiece needs a real browser with a GPU. `npm run dev` is the
> intended way to experience it.

## Stack

| Concern | Tool |
| --- | --- |
| App / tooling | React 18 · Vite 5 |
| WebGL | three.js · @react-three/fiber · drei · postprocessing |
| Shaders | hand-written GLSL (`src/three/shaders.js`) |
| Motion | GSAP + ScrollTrigger |
| Smooth scroll | Lenis |
| Fonts | Syne + Inter (bundled via `@fontsource-variable`, no runtime CDN) |

## Structure

```
src/
├── main.jsx              # entry — fonts + global styles
├── App.jsx               # composition, preloader hand-off, intro timeline
├── styles/global.css     # design system (palette, type, layout, cursor…)
├── data/projects.js      # the fictional brand's content
├── lib/
│   ├── gsap.js           # gsap + ScrollTrigger + signature easing
│   ├── lenis.js          # smooth scroll <-> gsap ticker wiring
│   ├── store.js          # shared pointer/scroll state for the WebGL layer
│   └── useReveal.js      # data-reveal scroll animations
├── three/
│   ├── shaders.js        # GLSL: simplex noise + displacement + fresnel
│   ├── ThresholdMaterial.js
│   ├── Threshold.jsx     # the 3D centerpiece
│   ├── Motes.jsx         # particle field
│   └── Scene.jsx         # <Canvas> + post-processing
└── components/           # Cursor, Preloader, Nav, Hero, Work, Studio, …
```

## Notes

- This is a fictional brand created for a portfolio/playground exercise. Names,
  clients, awards and people are invented.
- Tuning knobs worth playing with live in `src/three/ThresholdMaterial.js`
  (amplitude, frequency, fresnel, colors) and `src/three/Scene.jsx` (bloom).
